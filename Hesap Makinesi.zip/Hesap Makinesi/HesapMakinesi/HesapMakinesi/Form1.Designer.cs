﻿namespace HesapMakinesi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnnegatif = new Button();
            btnvirgül = new Button();
            btn0 = new Button();
            btntopla = new Button();
            btnesittir = new Button();
            btnçıkar = new Button();
            btn3 = new Button();
            btn2 = new Button();
            btn1 = new Button();
            btnbackspcae = new Button();
            btncarp = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            btnc = new Button();
            btnbolu = new Button();
            btn9 = new Button();
            btn8 = new Button();
            btn7 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // btnnegatif
            // 
            btnnegatif.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnnegatif.Location = new Point(7, 440);
            btnnegatif.Name = "btnnegatif";
            btnnegatif.Size = new Size(76, 94);
            btnnegatif.TabIndex = 0;
            btnnegatif.Text = "+/-";
            btnnegatif.UseVisualStyleBackColor = true;
            btnnegatif.Click += btnnegatif_Click;
            // 
            // btnvirgül
            // 
            btnvirgül.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnvirgül.Location = new Point(89, 440);
            btnvirgül.Name = "btnvirgül";
            btnvirgül.Size = new Size(76, 94);
            btnvirgül.TabIndex = 1;
            btnvirgül.Text = ",";
            btnvirgül.UseVisualStyleBackColor = true;
            btnvirgül.Click += btnvirgül_Click;
            // 
            // btn0
            // 
            btn0.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn0.Location = new Point(171, 440);
            btn0.Name = "btn0";
            btn0.Size = new Size(76, 94);
            btn0.TabIndex = 2;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += buttonlar;
            // 
            // btntopla
            // 
            btntopla.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btntopla.Location = new Point(253, 440);
            btntopla.Name = "btntopla";
            btntopla.Size = new Size(76, 94);
            btntopla.TabIndex = 3;
            btntopla.Text = "+";
            btntopla.UseVisualStyleBackColor = true;
            btntopla.Click += btntopla_Click;
            // 
            // btnesittir
            // 
            btnesittir.BackColor = Color.FromArgb(128, 255, 255);
            btnesittir.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnesittir.Location = new Point(335, 340);
            btnesittir.Name = "btnesittir";
            btnesittir.Size = new Size(76, 194);
            btnesittir.TabIndex = 4;
            btnesittir.Text = "=";
            btnesittir.UseVisualStyleBackColor = false;
            btnesittir.Click += btnesittir_Click;
            // 
            // btnçıkar
            // 
            btnçıkar.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnçıkar.Location = new Point(253, 340);
            btnçıkar.Name = "btnçıkar";
            btnçıkar.Size = new Size(76, 94);
            btnçıkar.TabIndex = 8;
            btnçıkar.Text = "-";
            btnçıkar.UseVisualStyleBackColor = true;
            btnçıkar.Click += btnçıkar_Click;
            // 
            // btn3
            // 
            btn3.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn3.Location = new Point(171, 340);
            btn3.Name = "btn3";
            btn3.Size = new Size(76, 94);
            btn3.TabIndex = 7;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += buttonlar;
            // 
            // btn2
            // 
            btn2.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn2.Location = new Point(89, 340);
            btn2.Name = "btn2";
            btn2.Size = new Size(76, 94);
            btn2.TabIndex = 6;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += buttonlar;
            // 
            // btn1
            // 
            btn1.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn1.Location = new Point(7, 340);
            btn1.Name = "btn1";
            btn1.Size = new Size(76, 94);
            btn1.TabIndex = 5;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += buttonlar;
            // 
            // btnbackspcae
            // 
            btnbackspcae.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnbackspcae.Location = new Point(335, 240);
            btnbackspcae.Name = "btnbackspcae";
            btnbackspcae.Size = new Size(76, 94);
            btnbackspcae.TabIndex = 14;
            btnbackspcae.Text = "<=";
            btnbackspcae.UseVisualStyleBackColor = true;
            btnbackspcae.Click += btnbackspcae_Click;
            // 
            // btncarp
            // 
            btncarp.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btncarp.Location = new Point(253, 240);
            btncarp.Name = "btncarp";
            btncarp.Size = new Size(76, 94);
            btncarp.TabIndex = 13;
            btncarp.Text = "*";
            btncarp.UseVisualStyleBackColor = true;
            btncarp.Click += btncarp_Click;
            // 
            // btn6
            // 
            btn6.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn6.Location = new Point(171, 240);
            btn6.Name = "btn6";
            btn6.Size = new Size(76, 94);
            btn6.TabIndex = 12;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += buttonlar;
            // 
            // btn5
            // 
            btn5.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn5.Location = new Point(89, 240);
            btn5.Name = "btn5";
            btn5.Size = new Size(76, 94);
            btn5.TabIndex = 11;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += buttonlar;
            // 
            // btn4
            // 
            btn4.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn4.Location = new Point(7, 240);
            btn4.Name = "btn4";
            btn4.Size = new Size(76, 94);
            btn4.TabIndex = 10;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += buttonlar;
            // 
            // btnc
            // 
            btnc.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnc.Location = new Point(335, 140);
            btnc.Name = "btnc";
            btnc.Size = new Size(76, 94);
            btnc.TabIndex = 19;
            btnc.Text = "C";
            btnc.UseVisualStyleBackColor = true;
            btnc.Click += btnc_Click;
            // 
            // btnbolu
            // 
            btnbolu.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnbolu.Location = new Point(253, 140);
            btnbolu.Name = "btnbolu";
            btnbolu.Size = new Size(76, 94);
            btnbolu.TabIndex = 18;
            btnbolu.Text = "/";
            btnbolu.UseVisualStyleBackColor = true;
            btnbolu.Click += btnbolu_Click;
            // 
            // btn9
            // 
            btn9.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn9.Location = new Point(171, 140);
            btn9.Name = "btn9";
            btn9.Size = new Size(76, 94);
            btn9.TabIndex = 17;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += buttonlar;
            // 
            // btn8
            // 
            btn8.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn8.Location = new Point(89, 140);
            btn8.Name = "btn8";
            btn8.Size = new Size(76, 94);
            btn8.TabIndex = 16;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += buttonlar;
            // 
            // btn7
            // 
            btn7.Font = new Font("Segoe UI Black", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btn7.Location = new Point(7, 140);
            btn7.Name = "btn7";
            btn7.Size = new Size(76, 94);
            btn7.TabIndex = 15;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += buttonlar;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI Symbol", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.Location = new Point(6, 61);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(404, 57);
            textBox1.TabIndex = 20;
            textBox1.Text = "0";
            textBox1.TextAlign = HorizontalAlignment.Right;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(422, 562);
            Controls.Add(btnçıkar);
            Controls.Add(textBox1);
            Controls.Add(btnc);
            Controls.Add(btnbolu);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btnbackspcae);
            Controls.Add(btncarp);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(btnesittir);
            Controls.Add(btntopla);
            Controls.Add(btn0);
            Controls.Add(btnvirgül);
            Controls.Add(btnnegatif);
            Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "HESAP MAKİNESİ";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnnegatif;
        private Button btnvirgül;
        private Button btn0;
        private Button btntopla;
        private Button btnesittir;
        private Button btnçıkar;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button btnbackspcae;
        private Button btncarp;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private Button btnc;
        private Button btnbolu;
        private Button btn9;
        private Button btn8;
        private Button btn7;
        private TextBox textBox1;
    }
}